<li class="hkb-meta__views">
    <?php echo ht_kb_view_count( get_the_ID() ); ?>
</li>